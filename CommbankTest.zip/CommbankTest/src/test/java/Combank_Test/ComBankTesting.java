package Combank_Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ComBankTesting 
{
	@Test
	public void test1() throws InterruptedException 
	
{
				
System.setProperty("webdriver.chrome.driver",System.getProperty("user.dir")+ "\\src\\main\\java\\resources\\chromedriver.exe");
		
WebDriver driver = new ChromeDriver();
					
driver.manage().window().maximize();
driver.get("https://commbank.com.au");
			
driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

driver.findElement(By.xpath("//*[@id='data-target-body-4']/ul/li[2]/a")).click();


driver.findElement(By.xpath("//*[text()='Banking']")).click();


driver.findElement(By.xpath("//*[text()='Home loans']")).click();


driver.findElement(By.xpath("//*[text()='Insurance']")).click();


driver.findElement(By.xpath("//*[text()='Investing & super']")).click();


driver.findElement(By.xpath("//*[text()='Business']")).click();

driver.findElement(By.xpath("//*[text()='Institutional']")).click();
driver.navigate().back();
driver.navigate().back();
driver.navigate().back();
driver.navigate().back();
driver.navigate().back();


WebDriverWait v =new WebDriverWait(driver,5);

v.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='data-target-body-4']/ul/li[2]/a")));


driver.findElement(By.xpath("//*[@id='data-target-body-4']/ul/li[2]/a")).click();

WebDriverWait w =new WebDriverWait(driver,7);

w.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("a[title='Use calculator']")));

driver.findElement(By.cssSelector("a[title='Use calculator']")).click();

Select s= new Select(driver.findElement(By.id("fx-source"))); 
s.selectByValue("GBP");
driver.findElement(By.cssSelector("input[data-ng-model='source']")).click();

driver.findElement(By.cssSelector("input[data-ng-model='source']")).sendKeys("300");

Select r= new Select(driver.findElement(By.id("fx-target"))); 

r.selectByValue("CAD");


driver.findElement(By.cssSelector("a[title='Send now']")).click();
driver.findElement(By.cssSelector("input[name='txtMyClientNumber$field']")).sendKeys("abcd");
driver.findElement(By.cssSelector("input[type='password']")).sendKeys("12345");
driver.findElement(By.cssSelector("input[class='button field']")).click();

	
driver.close();  
}
}
	


